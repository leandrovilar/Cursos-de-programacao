namespace MinimalApi.Dominio.Enuns;

public enum Perfil
{
    adm,
    editor
}