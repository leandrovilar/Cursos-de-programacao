namespace MinimalApi.Dominio.ModelViews;

public struct ErrosDeValidacao
{
    public List<string> Mensagens { get; set; }
   
}
